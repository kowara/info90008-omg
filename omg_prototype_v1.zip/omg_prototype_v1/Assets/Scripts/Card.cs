﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Card : MonoBehaviour
{
    public int id;
    public string factory;
    public string resource;
    public string productionGood;
    public int goodsPoint;
    public int victoryPoint;
    public int buildCost;
    public int halfSun;
    public string cardImage;

    //public int reqStone;
    //public int reqClay;
    //public int reqWheat;
    //public int reqCotton;
    //public int reqWood;
    //public int chainStone;
    //public int chainClay;
    //public int chainWheat;
    //public int chainCotton;
    //public int chainWood;
    //public int chainCoal;
    //public int chainIron;
    //public int chainFlour;
    //public int chainCattle;
    //public int chainCloth;
    //public int chainPlank;
    //public int chainGlass;
    //public int chainBread;
    //public int chainLeather;


}
