﻿/****************************************************************
 * PhaseTwo.cs
 ****************************************************************
 * Script for Phase Two, i.e.:
 * 
 * 1. draw cards from deck onto market until sunrise
 *  - is there still enough cards in the deck?
 *  - Y:
 *      - are there 2 Half-Suns yet?
 *      - Y:
 *          - go to Step 2
 *      - N: repeat Step 1
 *  - N:
 *      - are there enough Resource cards in the discard pile?
 *      - Y:
 *          - shuffle discard pile and put in deck
 *          - repeat Step 1
 *      - N:
 *          - discard half of the cards in player's hand
 *          - go to Y condition  
 *  
 * 2. let player assign Worker card to available Production Building
 *  - drag-and-drop Worker card to PB
 *  - decide whether the Worker card is Efficient or Sloppy
 *  
 * 3. set aside 1 Production Building card from hand
 *  - for use in Phase 4
 * 
 * 4. go to Phase 3
 ****************************************************************/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhaseTwo : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
