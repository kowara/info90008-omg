﻿/****************************************************************
 * PhaseFour.cs
 ****************************************************************
 * Script for Phase Four, i.e.:
 * 
 * 1. allow player to activate Production Buildings
 * (only if Worker is assigned to PB; one-time only)
 *  - drag-and-drop necessary Resource cards to PB
 *  - if Worker is Efficient:
 *      - reduce Resource card requirement by 1
 *      - if it's enough Resource cards to activate:
 *          - discard the used cards and activate PB
 *          - produce 1 Goods card and place on PB
 *
 * 2. allow player to activate Production Chain
 * (only if PB is active; can repeat multiple times)
 *  - drag-and-drop necessary Resource cards to PB
 *  - if it's enough to activate Chain:
 *      - discard the used cards
 *      - produce 1 Goods card and place on PB
 *      
 * 3. allow player to build new Production Building
 * - drag-and-drop necessary Resource cards to unbuilt PB
 * - if it's enough Resource cards to build:
 *      - discard the used cards
 *      - build new PB
 *  
 * 4. go to End of Round
 *  - have a button that allows player to end Phase 4 at any time
 *  - player should be able to do Steps 1-3 simultaneously
 *  - any cards that are unused but placed on PBs return to hand
 ****************************************************************/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhaseFour : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
