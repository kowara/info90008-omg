﻿/****************************************************************
 * PhaseOne.cs
 ****************************************************************
 * Script for Phase One, i.e.:
 * 
 * 1. ask player if they want to discard all cards in hand
 *  - generate Y/N prompt
 *  - Y:
 *      - discard all cards in hand
 *      - deal same number of discarded cards to player
 *  - N: skip to Step 2
 *  
 * 2. deal Resource cards to player
 *  - is there still enough cards in the deck?
 *  - Y:
 *      - deal 2 Resource cards to player
 *  - N:
 *      - are there enough Resource cards in the discard pile?
 *      - Y:
 *          - shuffle discard pile and put in deck
 *          - deal 2 Resource card to player
 *      - N:
 *          - discard half of the cards in player's hand
 *          - go to Y condition
 *          
 * 3. go to Phase 2
 ****************************************************************/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PhaseOne : MonoBehaviour
{

    public Font defaultFont;

    void DiscardPrompt()
    {
        //sets up prompt message
        GameObject discardPromptText = new GameObject();
        discardPromptText.transform.parent = GameObject.Find("Canvas").transform;
        discardPromptText.name = "DiscardPromptText";
        discardPromptText.AddComponent<Text>();
        discardPromptText.GetComponent<RectTransform>().sizeDelta = new Vector2(400, 100);
        discardPromptText.GetComponent<Text>().text = "Discard all cards in hand?";
        discardPromptText.GetComponent<Text>().font = defaultFont;
        discardPromptText.GetComponent<Text>().fontSize = 25;
        discardPromptText.GetComponent<Text>().alignment = TextAnchor.MiddleCenter;
        float xPosText = GameObject.Find("Canvas").transform.position.x;
        float yPosText = GameObject.Find("Canvas").transform.position.y;
        discardPromptText.transform.position = new Vector2(xPosText, yPosText);

        //gets buttonPrefab from LoadDeck script
        GameObject buttonPrefab = GameObject.Find("GameManager").GetComponent<LoadDeck>().buttonPrefab;

        //sets up Y/N prompt buttons
        GameObject yesDiscardAllCardsButton = (GameObject)Instantiate(buttonPrefab);
        GameObject noDiscardAllCardsButton = (GameObject)Instantiate(buttonPrefab);

        yesDiscardAllCardsButton.name = "YDiscardAll_Button";
        noDiscardAllCardsButton.name = "NDiscardAll_Button";

        yesDiscardAllCardsButton.transform.SetParent(GameObject.Find("GUI").transform);
        noDiscardAllCardsButton.transform.SetParent(GameObject.Find("GUI").transform);

        yesDiscardAllCardsButton.transform.GetChild(0).GetComponent<Text>().text = "Yes";
        noDiscardAllCardsButton.transform.GetChild(0).GetComponent<Text>().text = "No";

        yesDiscardAllCardsButton.GetComponent<Button>().onClick.AddListener(DiscardAllCards);
        noDiscardAllCardsButton.GetComponent<Button>().onClick.AddListener(DiscardAllCards);
    }

    void DiscardAllCards()
    {
        Destroy(GameObject.Find("DiscardPromptText"));
        Destroy(GameObject.Find("YDiscardAll_Button"));
        Destroy(GameObject.Find("NDiscardAll_Button"));
    }
}
