﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
[System.Serializable]


public class LoadDeck : MonoBehaviour
{    
    //GUI button prefab and what panel to attach them to
    public GameObject buttonPrefab;
    public GameObject panelToAttachButtonsTo;

    public GameObject cardPrefab;
    public GameObject cardPrefabSide;
    public GameObject halfSunPrefab;

    public GameObject resourcesCard;

    //default font used in game
    public Font defaultFont;

    public enum Phase { SETUP,PHASEONE,PHASETWO,PHASETHREE,PHASEFOUR };
    public Phase CurrentPhase = Phase.SETUP;

    //counter to keep track of amount of half-suns revealed
    private int sunCount = 0;

    private bool isDealToPlayer = false;
    private bool isDealToFactory = false;

    //lists for containing cards in the deck, player hand, and Market
    public List<GameObject> deck = new List<GameObject>();
    public List<GameObject> hand = new List<GameObject>();
    public List<GameObject> discard = new List<GameObject>();
    public List<GameObject> market = new List<GameObject>();

    //creates Card objects according to number of entries in deckdata.csv
    //assigns object parameters to each Card object
    void LoadFromCSV()
    {
        TextAsset deckdata = Resources.Load<TextAsset>("deckdata");

        string[] data = deckdata.text.Split(new char[] { '\n' });

        for (int i = 0; i < data.Length - 1; i++)
        {
            string[] row = data[i].Split(new char[] { ',' });

            if (row[0] != "")
            {
                GameObject cardBody = Instantiate(cardPrefab, new Vector2(0, 0), Quaternion.identity);
                cardBody.name = "ID" + i;
                cardBody.GetComponent<Draggable>().enabled = true;

                //adding Card script component to card
                Card c = cardBody.AddComponent<Card>();

                int.TryParse(row[0], out c.id);
                c.factory = row[1];
                c.resource = row[2];
                c.productionGood = row[3];
                int.TryParse(row[4], out c.goodsPoint);
                int.TryParse(row[5], out c.victoryPoint);
                int.TryParse(row[6], out c.buildCost);
                int.TryParse(row[7], out c.halfSun);
                c.cardImage = row[8];

                //replace the resource sprite name with the cardImage string from CSV file
                cardBody.GetComponent<Image>().sprite = Resources.Load<Sprite>("card_clay");

                deck.Add(cardBody);
            }
        }
    }

    void GameSetup()
    {
        //instantiates Worker in Worker Zone
        GameObject workerCard = Instantiate(cardPrefabSide, new Vector2(0, 0), Quaternion.identity) as GameObject;
        Transform workerPrefab = workerCard.GetComponent<Transform>();
        workerPrefab.transform.SetParent(GameObject.Find("WorkZone").GetComponent<Transform>());
        workerCard.GetComponent<Draggable>().enabled = false;

        //instantiates Charburner in Production Zone
        GameObject factoryCard = Instantiate(cardPrefab, new Vector2(0, 0), Quaternion.identity) as GameObject;
        factoryCard.name = "Charburner";
        Transform factoryPrefab = factoryCard.GetComponent<Transform>();
        factoryPrefab.transform.SetParent(GameObject.Find("ProductionZone").GetComponent<Transform>());
        factoryCard.GetComponent<Draggable>().enabled = false;

        //instantiates deck of cards in Deck Zone for dealing
        GameObject deckCard = Instantiate(cardPrefab, new Vector2(0, 0), Quaternion.identity) as GameObject;
        deckCard.name = "GameDeck";
        Transform deckPrefab = deckCard.GetComponent<Transform>();
        deckPrefab.transform.SetParent(GameObject.Find("DeckZone").GetComponent<Transform>());
        deckCard.GetComponent<Draggable>().enabled = false;
        Button deckButton = deckCard.AddComponent(typeof(Button)) as Button;
        deckCard.GetComponent<Button>().onClick.AddListener(StartSetup);
    }

    //deals cards to player
    private IEnumerator DealHandResources()
    {
        if (deck.Count > 0)
        {
            if (isDealToPlayer == false)
            {
                for (int i = 0; i < 5; i++)
                {
                    Debug.Log("The selected card is ID" + deck[i].GetComponent<Card>().id);
                    Debug.Log("and Factory Type " + deck[i].GetComponent<Card>().factory);

                    hand.Add(deck[i]);
                    deck.Remove(deck[i]);

                    Transform cardInHandPrefab = hand[i].GetComponent<Transform>();
                    cardInHandPrefab.transform.SetParent(GameObject.Find("Hand").GetComponent<Transform>());

                    yield return new WaitForSeconds(0.5f);
                }

                isDealToPlayer = true;

                //GameObject deckDealFactoryResources = GameObject.Find("GameDeck");
            }
        }

        else if (deck.Count == 0)
        {
            Debug.Log("No more cards in deck! Grab from Discard pile or player hand!");
            //do deck refill stuff here
        }
    }

    private IEnumerator DealFactoryResources()
    {
        List<GameObject> charburner = new List<GameObject>();

        if (deck.Count > 0)
        {
            if (isDealToFactory == false)
            {
                float cardX = GameObject.Find("Charburner").GetComponent<Transform>().position.x;
                float cardY = GameObject.Find("Charburner").GetComponent<Transform>().position.y;
                float cardZ = GameObject.Find("Charburner").GetComponent<Transform>().position.z;

                for (int i = 6; i >= 0; i--)
                {
                    cardY = cardY + 5.0f;

                    Transform cardInFactoryPrefab = deck[i].GetComponent<Transform>();
                    cardInFactoryPrefab.Rotate(0, 0, 90, Space.World);
                    cardInFactoryPrefab.transform.SetParent(GameObject.Find("Charburner").GetComponent<Transform>());

                    Vector3 cardInFactoryPosition = new Vector3(cardX, cardY, cardZ);
                    cardInFactoryPrefab.transform.position = cardInFactoryPrefab.transform.position + cardInFactoryPosition;

                    charburner.Add(deck[i]);
                    deck.Remove(deck[i]);

                    yield return new WaitForSeconds(0.5f);

                }

                isDealToFactory = true;

                //change to PHASEONE once it's set up later!!
                CurrentPhase = Phase.PHASEONE;
                PhaseSwitch(Phase.PHASEONE);
            }
        }

        else if (deck.Count == 0)
        {
            Debug.Log("No more cards in deck! Grab from Discard pile or player hand!");
            //do deck refill stuff here
        }
    }
    

    //adds cards to the Market until two half-suns are revealed
    void DealMarket()
    {
        if (sunCount < 2 && deck.Count > 0)
        {
            Transform cardInMarketPrefab = deck[0].GetComponent<Transform>();
            cardInMarketPrefab.transform.SetParent(GameObject.Find("MarketZone").GetComponent<Transform>());

            market.Add(deck[0]);

            //Debug.Log("The card added to the Market is of ID" + market[0].id);
            sunCount = sunCount + deck[0].GetComponent<Card>().halfSun;

            Debug.Log("Current sun status is " + sunCount + " sun(s)");

            if (deck[0].GetComponent<Card>().halfSun == 1)
            {
                GameObject halfSunImage = Instantiate(halfSunPrefab, new Vector2(0, 0), Quaternion.identity) as GameObject;
                Transform phaseSunPrefab = halfSunImage.GetComponent<Transform>();

                if (CurrentPhase == Phase.PHASETWO)
                {
                    phaseSunPrefab.transform.SetParent(GameObject.Find("MorningSunZone").GetComponent<Transform>());
                }

                else if (CurrentPhase == Phase.PHASETHREE)
                {
                    phaseSunPrefab.transform.SetParent(GameObject.Find("NightSunZone").GetComponent<Transform>());
                }
            }

            deck.Remove(deck[0]);

            if (sunCount == 2)
            {
                if (CurrentPhase == Phase.PHASETWO)
                {
                    CurrentPhase = Phase.PHASETHREE;
                    PhaseSwitch(Phase.PHASETHREE);
                }

                else if (CurrentPhase == Phase.PHASETHREE)
                {
                    CurrentPhase = Phase.PHASEFOUR;
                    PhaseSwitch(Phase.PHASEFOUR);
                }
            }
        }
        
        else if (sunCount < 2 && deck.Count == 0)
        {
            Debug.Log("The number of cards in the Market are " + market.Count + " card(s)");
            Debug.Log("The deck is empty! Please refill!");
            //do deck refill stuff here
        }
    }

    //shuffles the card deck based on the Fisher-Yates shuffle algorithm
    void Shuffle(List<GameObject> cardDeck)
    {
        Debug.Log("Shuffling cards...");
        for (int i = deck.Count - 1; i >= 0; --i)
        {
            int r = UnityEngine.Random.Range(0, i + 1);
            var tmp = cardDeck[i];
            cardDeck[i] = cardDeck[r];
            cardDeck[r] = tmp;

            //Debug.Log(cardDeck[i].GetComponent<Card>().id);
        }
    }

    void DiscardPrompt()
    {
        //sets up prompt message
        GameObject discardPromptText = new GameObject();
        discardPromptText.transform.parent = GameObject.Find("Canvas").transform;
        discardPromptText.name = "DiscardPromptText";
        discardPromptText.AddComponent<Text>();
        discardPromptText.GetComponent<RectTransform>().sizeDelta = new Vector2(400, 100);
        discardPromptText.GetComponent<Text>().text = "Discard all cards in hand?";
        discardPromptText.GetComponent<Text>().font = defaultFont;
        discardPromptText.GetComponent<Text>().fontSize = 25;
        discardPromptText.GetComponent<Text>().alignment = TextAnchor.MiddleCenter;
        float xPosText = GameObject.Find("Canvas").transform.position.x;
        float yPosText = GameObject.Find("Canvas").transform.position.y;
        discardPromptText.transform.position = new Vector2(xPosText, yPosText);

        //gets buttonPrefab from LoadDeck script
        GameObject buttonPrefab = GameObject.Find("GameManager").GetComponent<LoadDeck>().buttonPrefab;

        //sets up Y/N prompt buttons
        GameObject yesDiscardAllCardsButton = (GameObject)Instantiate(buttonPrefab);
        GameObject noDiscardAllCardsButton = (GameObject)Instantiate(buttonPrefab);

        yesDiscardAllCardsButton.name = "YDiscardAll_Button";
        noDiscardAllCardsButton.name = "NDiscardAll_Button";

        yesDiscardAllCardsButton.transform.SetParent(GameObject.Find("GUI").transform);
        noDiscardAllCardsButton.transform.SetParent(GameObject.Find("GUI").transform);

        yesDiscardAllCardsButton.transform.GetChild(0).GetComponent<Text>().text = "Yes";
        noDiscardAllCardsButton.transform.GetChild(0).GetComponent<Text>().text = "No";

        yesDiscardAllCardsButton.GetComponent<Button>().onClick.AddListener(StartPhaseOne);
        noDiscardAllCardsButton.GetComponent<Button>().onClick.AddListener(StartPhaseOneNoDiscard);
    }

    private IEnumerator DiscardAllCards()
    {
        int discardedCount = hand.Count;

        for (int i = hand.Count - 1; i >= 0; i--)
        {
            Transform cardToDiscardPrefab = hand[i].GetComponent<Transform>();
            cardToDiscardPrefab.transform.SetParent(GameObject.Find("DiscardPile").GetComponent<Transform>());
            discard.Add(hand[i]);
            hand.Remove(hand[i]);

            yield return new WaitForSeconds(0.5f);
        }

        for (int i = discardedCount - 1; i >= 0; i--)
        {
            Transform cardToRedrawPrefab = deck[i].GetComponent<Transform>();
            cardToRedrawPrefab.transform.SetParent(GameObject.Find("Hand").GetComponent<Transform>());
            hand.Add(deck[i]);
            deck.Remove(deck[i]);

            yield return new WaitForSeconds(0.5f);
        }
        StartCoroutine(DealHandResourcesPhaseOne());
    }

    private IEnumerator DealHandResourcesPhaseOne()
    {
        if (deck.Count > 0)
        {
            for (int i = 0; i < 2; i++)
            {
                Debug.Log("The selected card is ID" + deck[i].GetComponent<Card>().id);
                Debug.Log("and Factory Type " + deck[i].GetComponent<Card>().factory);

                Transform cardInHandPrefab = deck[i].GetComponent<Transform>();
                cardInHandPrefab.transform.SetParent(GameObject.Find("Hand").GetComponent<Transform>());

                hand.Add(deck[i]);
                deck.Remove(deck[i]);

                yield return new WaitForSeconds(0.5f);
            }
        }
        CurrentPhase = Phase.PHASETWO;
        PhaseSwitch(Phase.PHASETWO);
    }

    void Awake()
    {
        GameObject buttonSetup = GameObject.Find("Setup");
        buttonSetup.GetComponent<Button>().onClick.AddListener(StartGame);
    }

    void Update()
    {
        //ClickManager();
    }


    //starts a game of Oh My Goods!
    void StartGame()
    {
        PhaseSwitch(Phase.SETUP);
    }

    void StartSetup()
    {
        if (isDealToPlayer == false)
        {
            StartCoroutine(DealHandResources());
        }

        else if (isDealToPlayer == true)
        {
            StartCoroutine(DealFactoryResources());
        }
    }

    //starts Phase One
    void StartPhaseOne()
    {
        Destroy(GameObject.Find("DiscardPromptText"));
        Destroy(GameObject.Find("YDiscardAll_Button"));
        Destroy(GameObject.Find("NDiscardAll_Button"));
        StartCoroutine(DiscardAllCards());
    }

    //starts Phase One without Discard step
    void StartPhaseOneNoDiscard()
    {
        Destroy(GameObject.Find("DiscardPromptText"));
        Destroy(GameObject.Find("YDiscardAll_Button"));
        Destroy(GameObject.Find("NDiscardAll_Button"));
        StartCoroutine(DealHandResourcesPhaseOne());
    }

    //starts Phase Two
    void StartPhaseTwo()
    {

    }

    //starts Phase Three
    void StartPhaseThree()
    {

    }

    //starts Phase Four
    void StartPhaseFour()
    {

    }


    void PhaseSwitch(Phase CurrentPhase) {

        switch (CurrentPhase)
        {
            case Phase.SETUP:
                Debug.Log("Beginning Setup...");
                LoadFromCSV();
                Shuffle(deck);
                GameSetup();
                break;
            case Phase.PHASEONE:
                Debug.Log("Beginning Phase One...");
                DiscardPrompt();

                break;
            case Phase.PHASETWO:
                Debug.Log("Beginning Phase Two...");

                //placeholder for testing
                //GameObject buttonPhaseTwo = GameObject.Find("Phase2");
                //buttonPhaseTwo.GetComponent<Button>().onClick.AddListener(StartPhaseTwo);

                GameObject deckCardSunPhase = GameObject.Find("GameDeck");
                //deckCardSunPhase.GetComponent<Button>().onClick.RemoveListener(DealFactoryResources);
                deckCardSunPhase.GetComponent<Button>().onClick.AddListener(DealMarket);

                break;
            case Phase.PHASETHREE:
                Debug.Log("Beginning Phase Three...");

                //placeholder
                //GameObject buttonPhaseThree = GameObject.Find("Phase3");
                //buttonPhaseThree.GetComponent<Button>().onClick.AddListener(StartPhaseThree);

                //resets sun count for use in next Phase(s)
                sunCount = 0;

                break;
            case Phase.PHASEFOUR:
                Debug.Log("Beginning Phase Four...");

                GameObject deckCardProductionPhase = GameObject.Find("GameDeck");
                deckCardProductionPhase.GetComponent<Button>().onClick.RemoveListener(DealMarket);

                //resets sun count for use in next Phase(s)
                sunCount = 0;

                //placeholder
                //GameObject buttonPhaseFour = GameObject.Find("Phase4");
                //buttonPhaseFour.GetComponent<Button>().onClick.AddListener(StartPhaseFour);

                break;
            default:
                break;
        }
    }
}
