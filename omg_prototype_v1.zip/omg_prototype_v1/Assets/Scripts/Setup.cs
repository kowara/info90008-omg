﻿/****************************************************************
 * Setup.cs
 ****************************************************************
 * Script to set up gameplay, i.e.:
 * 
 * 1. deck generation
 *  - load card data from external CSV file
 *  - generate card GameObjects in play and place in deck
 * 
 * 2. deal player starting cards
 *  - deal 1 Worker card to player
 *  - deal 1 Charburner card to player
 * 
 * 3. deal Resource cards to player
 *  - shuffle deck
 *  - deal 5 Resource cards to player's hand
 *  - deal 7 Resources cards to player's Charburner
 *  
 * 4. go to Phase 1
 ****************************************************************/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Setup : MonoBehaviour
{
    void Awake()
    {
        
    }

}
